﻿using SistUnikivi.Avaliacoes;
using SistUnikivi.Modelos;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Logica
{
    public class UnidadeCurricular
    {
        public string NomeUC { get; set; }

        // Agregação: Os estudantes existem independentemente da UC
        public List<Estudante> Inscritos { get; set; } = [];

        // Composição: As avaliações são criadas e geridas pela UC
        private List<Avaliacao> _avaliacoesDaUC = new List<Avaliacao>();

        public void AdicionarEstudante(Estudante e) => Inscritos.Add(e);

        public void ConfigurarAvaliacao(Avaliacao av) => _avaliacoesDaUC.Add(av);

        public void EmitirPauta()
        {
            Console.WriteLine($"\nPAUTA FINAL: {NomeUC.ToUpper()}");
            Console.WriteLine(new string('=', 45));
            Console.WriteLine("{0,-25} | {1,-10}", "NOME DO ESTUDANTE", "RESULTADO");
            Console.WriteLine(new string('-', 45));

            var ordenados = Inscritos.OrderBy(e => e.Nome).ToList();

            foreach (var est in ordenados)
            {
                // Soma as notas ponderadas que pertencem a ESTE estudante
                double total = est.Notas.Sum(a => a.ObterNotaPonderada());
                Console.WriteLine("{0,-25} | {1,-10:N2}", est.Nome, total);
            }
            Console.WriteLine(new string('=', 45));
        }
    }
}