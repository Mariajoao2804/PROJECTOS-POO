﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Interfaces
{
    public interface IAvaliavel
    {
         double CalcularNotaFinal();
    }
}
