﻿using SistUnikivi.Avaliacoes;
using SistUnikivi.Logica;
using SistUnikivi.Modelos;
using System;

class Program
{
    static void Main()
    {
        UnidadeCurricular uc = new UnidadeCurricular { NomeUC = "Programação Orientada a Objetos" };
        bool continuar = true;

        while (continuar)
        {
            Console.Clear();
            Console.WriteLine($"=== GESTÃO DE NOTAS: {uc.NomeUC} ===");
            Console.WriteLine("1. Registar Estudante e Notas");
            Console.WriteLine("2. Emitir Pauta Final");
            Console.WriteLine("0. Sair");
            Console.Write("\nEscolha uma opção: ");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    RegistarEstudanteComNotas(uc);
                    break;
                case "2":
                    Console.Clear();
                    uc.EmitirPauta();
                    Pausar();
                    break;
                case "0":
                    continuar = false;
                    break;
            }
        }
    }

    static void RegistarEstudanteComNotas(UnidadeCurricular uc)
    {
        Console.Clear();
        Console.WriteLine("--- NOVO REGISTO DE NOTAS ---");

        Estudante novoEstudante = new Estudante();
        Console.Write("Nome do Estudante: ");
        novoEstudante.Nome = Console.ReadLine() ?? "Sem Nome";

        Console.Write("Número de Matrícula: ");
        int.TryParse(Console.ReadLine(), out int matricula);
        novoEstudante.NumeroMatricula = matricula;

        // Captura das notas usando o novo método LerNota
        double n1 = LerNota("Nota do Teste (30%): ");
        double n2 = LerNota("Nota do Projecto (40%): ");
        double n3 = LerNota("Nota do Exame Final (30%): ");

        // Adiciona as notas ao objeto do estudante
        novoEstudante.Notas.Add(new Teste { Descricao = "Teste", Nota = n1, Peso = 0.3 });
        novoEstudante.Notas.Add(new Projecto { Descricao = "Projecto", Nota = n2, Peso = 0.4 });
        novoEstudante.Notas.Add(new ExameFinal { Descricao = "Exame", Nota = n3, Peso = 0.3 });

        uc.AdicionarEstudante(novoEstudante);
        Console.WriteLine("\nEstudante e notas registados com sucesso!");
        Pausar();
    }

    // ESTE É O MÉTODO QUE ESTAVA A FALTAR (Copia isto para o final da classe Program)
    static double LerNota(string mensagem)
    {
        double nota;
        while (true)
        {
            Console.Write(mensagem);
            string entrada = Console.ReadLine();

            // Verifica se é um número válido
            if (double.TryParse(entrada, out nota))
            {
                if (nota >= 0 && nota <= 20) return nota;
                Console.WriteLine("Erro: A nota deve estar entre 0 e 20.");
            }
            else
            {
                Console.WriteLine("Erro: Entrada inválida. Digite um número.");
            }
        }
    }

    static void Pausar()
    {
        Console.WriteLine("\nPressione qualquer tecla para continuar...");
        Console.ReadKey();
    }
}