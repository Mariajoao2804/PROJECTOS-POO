﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Modelos
{
    public abstract class Pessoa
    {
        public string Nome { get; set; }
        public string ID { get; set; }
    }
}
