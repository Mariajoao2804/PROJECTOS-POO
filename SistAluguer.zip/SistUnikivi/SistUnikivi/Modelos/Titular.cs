﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Modelos
{
    internal class Titular:Docente
    {
    }
}
