﻿using SistUnikivi.Avaliacoes;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Modelos
{
    public class Estudante: Pessoa
    {
        public int NumeroMatricula { get; set; }
        // Lista de notas específica deste estudante
        public List<Avaliacao> Notas { get; set; } = new List<Avaliacao>();
    }
}
