﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Modelos
{
    public class Assistente:Docente 
    {
    }
}
