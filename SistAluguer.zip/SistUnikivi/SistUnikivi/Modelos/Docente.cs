﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Modelos
{
    public abstract class Docente : Pessoa
    {
        public string Departamento { get; set; }
    }

}


