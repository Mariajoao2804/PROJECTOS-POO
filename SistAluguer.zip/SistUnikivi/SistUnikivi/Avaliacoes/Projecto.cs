﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Avaliacoes
{
    public class Projecto: Avaliacao
    {
        public override double ObterNotaPonderada() => Nota * Peso;
    }
}
