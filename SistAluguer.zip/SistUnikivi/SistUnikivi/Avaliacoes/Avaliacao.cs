﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistUnikivi.Avaliacoes
{
    public abstract class Avaliacao
    {
        public string Descricao { get; set; }
        public double Nota { get; set; }
        public double Peso { get; set; } // Ex: 0.4 para 40%

        public abstract double ObterNotaPonderada();
    }
}