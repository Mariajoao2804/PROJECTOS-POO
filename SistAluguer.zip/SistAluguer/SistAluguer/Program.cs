﻿using SistAluguer.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    // Lista para armazenar a frota de veículos
    static List<Veiculo> frota = new List<Veiculo>();

    static void Main()
    {
        int opcao = -1;

        while (opcao != 0)
        {
            Console.Clear();
            Console.WriteLine("=== SISTEMA DE GESTÃO PARA ALUGUER DE VEICULOS");
            Console.WriteLine("1. Registar Novo Veículo");
            Console.WriteLine("2. Atualizar Quilometragem (Pós-Aluguer)");
            Console.WriteLine("3. Consultar Dados de um Veículo");
            Console.WriteLine("4. Listar Todos os Veículos");
            Console.WriteLine("0. Sair");
            Console.Write("\nEscolha uma opção: ");

            if (!int.TryParse(Console.ReadLine(), out opcao)) continue;

            switch (opcao)
            {
                case 1:
                    MenuRegistar();
                    break;
                case 2:
                    MenuAtualizar();
                    break;
                case 3:
                    MenuConsultar();
                    break;
                case 4:
                    ListarFrota();
                    break;
                case 0:
                    Console.WriteLine("A encerrar o sistema...");
                    break;
                default:
                    Console.WriteLine("Opção inválida!");
                    Pausar();
                    break;
            }
        }
    }

    // --- Métodos de Apoio ao Menu ---

    static void MenuRegistar()
    {
        Console.Clear();
        Console.WriteLine("--- REGISTAR VEÍCULO ---");

        Veiculo novo = new Veiculo();

        Console.Write("Matrícula: ");
        novo.Matricula = Console.ReadLine();

        Console.Write("Marca: ");
        novo.Marca = Console.ReadLine();

        Console.Write("Modelo: ");
        novo.Modelo = Console.ReadLine();

        Console.Write("Ano de Fabricação: ");
        novo.Ano = int.Parse(Console.ReadLine());

        Console.Write("Quilometragem Inicial: ");
        double kms = double.Parse(Console.ReadLine());
        // Como o set da quilometragem é privado, usamos o método para definir o valor inicial
        novo.ActualizarQuilometragem(kms);

        frota.Add(novo);
        Console.WriteLine("\nVeículo registado com sucesso!");
        Pausar();
    }

    static void MenuAtualizar()
    {
        Console.Clear();
        Console.WriteLine("--- ATUALIZAR QUILOMETRAGEM ---");
        Console.Write("Introduza a matrícula do veículo: ");
        string mat = Console.ReadLine();

        var v = frota.FirstOrDefault(x => x.Matricula.Equals(mat, StringComparison.OrdinalIgnoreCase));

        if (v != null)
        {
            Console.Write($"Quilometragem atual: {v.Quilometragem} km. \nQuanto percorreu no último aluguer? ");
            double kms = double.Parse(Console.ReadLine());
            v.ActualizarQuilometragem(kms);
        }
        else
        {
            Console.WriteLine("Veículo não encontrado.");
        }
        Pausar();
    }

    static void MenuConsultar()
    {
        Console.Clear();
        Console.Write("Introduza a matrícula para consulta: ");
        string mat = Console.ReadLine();

        var v = frota.FirstOrDefault(x => x.Matricula.Equals(mat, StringComparison.OrdinalIgnoreCase));

        if (v != null)
            v.ApresentarDados();
        else
            Console.WriteLine("Veículo não encontrado.");

        Pausar();
    }

    static void ListarFrota()
    {
        Console.Clear();
        Console.WriteLine("--- LISTAGEM DE FROTA ---");
        if (frota.Count == 0) Console.WriteLine("Nenhum veículo registado.");

        foreach (var v in frota)
        {
            v.ApresentarDados();
        }
        Pausar();
    }

    static void Pausar()
    {
        Console.WriteLine("\nPressione qualquer tecla para continuar...");
        Console.ReadKey();
    }
}