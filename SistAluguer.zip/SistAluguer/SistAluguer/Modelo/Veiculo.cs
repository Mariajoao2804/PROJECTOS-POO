﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistAluguer.Modelo
{

    using System;

    public class Veiculo
    {
        // Atributos Privados (Campos)
        private string _matricula;
        private string _marca;
        private string _modelo;
        private int _ano;
        private double _quilometragem;

        // Propriedades (Encapsulamento com get/set)
        public string Matricula
        {
            get { return _matricula; }
            set { _matricula = value; }
        }

        public string Marca
        {
            get { return _marca; }
            set { _marca = value; }
        }

        public string Modelo
        {
            get { return _modelo; }
            set { _modelo = value; }
        }

        public int Ano
        {
            get { return _ano; }
            set { _ano = value; }
        }

        public double Quilometragem
        {
            get { return _quilometragem; }
            // Set privado ou lógica de validação poderia ser inserida aqui
            private set { _quilometragem = value; }
        }

        // --- Construtores ---

        // Construtor sem parâmetros (Default)
        public Veiculo()
        {
        }

        // Construtor parametrizado
        public Veiculo(string matricula, string marca, string modelo, int ano, double quilometragem)
        {
            _matricula = matricula;
            _marca = marca;
            _modelo = modelo;
            _ano = ano;
            _quilometragem = quilometragem;
        }

        // --- Métodos ---

        public void ActualizarQuilometragem(double kmsPercorridos)
        {
            if (kmsPercorridos > 0)
            {
                _quilometragem += kmsPercorridos;
                Console.WriteLine($"[Sistema] Quilometragem de {_matricula} actualizada para {_quilometragem} km.");
            }
            else
            {
                Console.WriteLine("[Erro] Valor de quilometragem inválido.");
            }
        }

        public void ApresentarDados()
        {
            Console.WriteLine("\nFICHA DO VEÍCULO ");
            Console.WriteLine("{0, -15} {1, -15} {2, 15} {3, -15} {4, -15}", "Matrícula", "Marca", "Modelo", "Ano", "Quilometragem");
            Console.WriteLine("\n{0, -15} {1, -15} {2, 15} {3, -15} {4, -15} ", _matricula, _marca, _modelo, _ano, _quilometragem);
            Console.WriteLine("");
        }
    }
}